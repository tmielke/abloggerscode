DESCRIPTION:
------------
This demo shows numerous ways of using a Camel Aggregator. I added a couple 
of different aggregator configurations that basically all do the same job. 
Only one of the routes that use the aggregator should be active at runtime, 
otherwise the resulting output can be misleading!
I suggest to read the Forum article for background discussion on the Camel aggregator.

Logging can be controlled by editing src/main/resources/log4j.properties.



PREREQUISITES:
--------------
Maven and JDK 1.5 only. All the rest can be downloaded by Maven.



COMPILING:
----------
Simply run mvn install.
There also is an Eclipse project included with the demo. 



RUNNING:
---------
You can run this demo standalone without having to deploy into any container 
by invoking 
mvn camel:run



OUTPUT:
---------
The output will vary according to aggregator config used but for the default
route it should read for the first couple of messages:

2009-01-22 16:02:06,236 INFO  MainSupport                    - Generating DOT file for routes: c:\tmi\Projects\FUSE\Camel\CamelAggregatorTest\target/site/cameldoc for: org.apache.camel.spring.SpringCamelContext@935741 with name: camel
2009-01-22 16:02:11,213 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,213 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,223 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,223 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,223 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,223 DEBUG MyAggregationStrategy          - aggregated header is set to 4
2009-01-22 16:02:11,233 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,233 DEBUG MyAggregationStrategy          - aggregated header is set to 5
2009-01-22 16:02:11,243 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,253 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,253 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,253 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,263 DEBUG MyAggregationStrategy          - aggregated header is set to 4
2009-01-22 16:02:11,263 DEBUG MyAggregationStrategy          - aggregated header is set to 4
2009-01-22 16:02:11,273 DEBUG MyAggregationStrategy          - aggregated header is set to 4
2009-01-22 16:02:11,273 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,273 DEBUG MyAggregationStrategy          - aggregated header is set to 3
2009-01-22 16:02:11,273 DEBUG MyAggregationStrategy          - aggregated header is set to 4
2009-01-22 16:02:11,273 DEBUG MyAggregationStrategy          - aggregated header is set to 5
2009-01-22 16:02:11,283 DEBUG MyAggregationStrategy          - aggregated header is set to 5
2009-01-22 16:02:11,283 DEBUG MyAggregationStrategy          - aggregated header is set to 5
2009-01-22 16:02:11,283 DEBUG MyAggregationStrategy          - aggregated header is set to 5
2009-01-22 16:02:11,303 DEBUG MyAggregationStrategy          - aggregated header is set to 2
2009-01-22 16:02:11,303 INFO  AggregateOnXPath3              - Exchange[Id:ID-nbtmielke/4762-1232636526096/0-9, BodyType:String, Body:<artist genre="Rock">  <name>The Rolling Stones</name>  <album>Let It Bleed</album>  <album>Stripped</album>  <album>Forty Licks</album></artist><artist genre="Rock">  <name>Keane</name>  <album>Perfect Symmetry</album>  <album>Under the Iron Sea</album>  <album>Hopes and Fears</album></artist><artist genre="Rock">  <name>The Rolling Stones</name>  <album>Let It Bleed</album>  <album>Stripped</album>  <album>Forty Licks</album></artist><artist genre="Rock">  <name>Keane</name>  <album>Perfect Symmetry</album>  <album>Under the Iron Sea</album>  <album>Hopes and Fears</album></artist><artist genre="Rock">  <name>The Rolling Stones</name>  <album>Let It Bleed</album>  <album>Stripped</album>  <album>Forty Licks</album></artist>]
2009-01-22 16:02:11,303 INFO  AggregateOnXPath3              - Exchange[Id:ID-nbtmielke/4762-1232636526096/0-10, BodyType:String, Body:<artist genre="Alternative">  <name>White Stripes</name>  <album>Elephant</album>  <album>Get Behind Me Satan</album>  <album>White Blood Cells</album></artist><artist genre="Alternative">  <name>White Stripes</name>  <album>Elephant</album>  <album>Get Behind Me Satan</album>  <album>White Blood Cells</album></artist><artist genre="Alternative">  <name>White Stripes</name>  <album>Elephant</album>  <album>Get Behind Me Satan</album>  <album>White Blood Cells</album></artist><artist genre="Alternative">  <name>White Stripes</name>  <album>Elephant</album>  <album>Get Behind Me Satan</album>  <album>White Blood Cells</album></artist><artist genre="Alternative">  <name>White Stripes</name>  <album>Elephant</album>  <album>Get Behind Me Satan</album>  <album>White Blood Cells</album></artist>]
2009-01-22 16:02:11,314 INFO  AggregateOnXPath3              - Exchange[Id:ID-nbtmielke/4762-1232636526096/0-11, BodyType:String, Body:<artist genre="Jazz">  <name>Jamie Cullum</name>  <album>Twenty Something</album>  <album>Catching Tales</album>  <album>Pointless Nostalgic</album></artist><artist genre="Jazz">  <name>Jamie Cullum</name>  <album>Twenty Something</album>  <album>Catching Tales</album>  <album>Pointless Nostalgic</album></artist><artist genre="Jazz">  <name>Jamie Cullum</name>  <album>Twenty Something</album>  <album>Catching Tales</album>  <album>Pointless Nostalgic</album></artist><artist genre="Jazz">  <name>Jamie Cullum</name>  <album>Twenty Something</album>  <album>Catching Tales</album>  <album>Pointless Nostalgic</album></artist><artist genre="Jazz">  <name>Jamie Cullum</name>  <album>Twenty Something</album>  <album>Catching Tales</album>  <album>Pointless Nostalgic</album></artist>]
2009-01-22 16:02:11,314 INFO  AggregateOnXPath3              - Exchange[Id:ID-nbtmielke/4762-1232636526096/0-12, BodyType:String, Body:<artist genre="World">  <name>Laura Lopez Castro</name>  <album>Mi Libro Abierto</album></artist><artist genre="World">  <name>Laura Lopez Castro</name>  <album>Mi Libro Abierto</album></artist><artist genre="World">  <name>Laura Lopez Castro</name>  <album>Mi Libro Abierto</album></artist><artist genre="World">  <name>Laura Lopez Castro</name>  <album>Mi Libro Abierto</album></artist><artist genre="World">  <name>Laura Lopez Castro</name>  <album>Mi Libro Abierto</album></artist>]
2009-01-22 16:02:11,314 INFO  AggregateOnXPath3              - Exchange[Id:ID-nbtmielke/4762-1232636526096/0-13, BodyType:String, Body:<artist genre="Rock">  <name>Keane</name>  <album>Perfect Symmetry</album>  <album>Under the Iron Sea</album>  <album>Hopes and Fears</album></artist><artist genre="Rock">  <name>The Rolling Stones</name>  <album>Let It Bleed</album>  <album>Stripped</album>  <album>Forty Licks</album></artist><artist genre="Rock">  <name>Keane</name>  <album>Perfect Symmetry</album>  <album>Under the Iron Sea</album>  <album>Hopes and Fears</album></artist><artist genre="Rock">  <name>The Rolling Stones</name>  <album>Let It Bleed</album>  <album>Stripped</album>  <album>Forty Licks</album></artist><artist genre="Rock">  <name>Keane</name>  <album>Perfect Symmetry</album>  <album>Under the Iron Sea</album>  <album>Hopes and Fears</album></artist>]
