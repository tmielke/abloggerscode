
package com.progress.cs.camelaggregatortest;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.camel.Header;

/**
 * A custom aggregation strategy implementation.
 * It aggregates two messages together by appending the newer
 * message to the older message.
 * @author TMIELKE, TMIELKE@progress.com
 * @version 1.0
 *
 */
public class MyAggregationStrategy implements AggregationStrategy {

	//Logger
  private Log log = null;
  
  //constructor
  public MyAggregationStrategy() {
	  log = LogFactory.getLog(MyAggregationStrategy.class);
  }
  
  /* (non-Javadoc)
	 * @see org.apache.camel.processor.aggregate.AggregationStrategy#aggregate(org.apache.camel.Exchange, org.apache.camel.Exchange)
	 */
  public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

  	//retrieve messages from both exchanges and concatenate them together.
  	//thereafter store concatenated message in newExchange.
  	Message newIn = newExchange.getIn();
	  String oldBody = oldExchange.getIn().getBody(String.class);
	  String newBody = newIn.getBody(String.class);
	  newIn.setBody(oldBody + newBody);
	  
	  //also set counter property on the new msg 
	  //so that we can check how many msgs got aggregated already.
	  Integer counter = (Integer) oldExchange.getProperty("aggregated");
	  if (counter == null) {
		  counter = 1;
    }
	  counter++;
	  newExchange.setProperty("aggregated", counter);
	  log.debug("aggregated header is set to " + counter);
	  
	  return newExchange;
   }
  
  
  /**
   * An expression used to determine if the aggregation is complete.
   * Only called if explicitly specified in the completedPredicate() clause of the aggregation.
   */
  public boolean isCompleted(@Header(name = "aggregated")
                             Integer aggregated) {
    
  	log.debug("isCompleted called.");
  	if (aggregated == null) {
          return false;
    }
    return aggregated == 5;
  }
}

