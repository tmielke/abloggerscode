package com.progress.cs.camelaggregatortest;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.builder.xml.XPathBuilder;
import org.apache.camel.language.bean.BeanExpression;

/*
import org.apache.camel.model.language.SimpleExpression;
import org.apache.camel.Expression;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Header;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.camel.processor.aggregate.AggregationCollection;
import org.apache.camel.processor.aggregate.PredicateAggregationCollection;
import org.apache.camel.processor.aggregate.UseLatestAggregationStrategy;
import org.apache.camel.model.language.MethodCallExpression;
import static org.apache.camel.builder.xml.XPathBuilder.xpath;
import org.apache.camel.builder.xml.Namespaces; 
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
*/


/**
 * TODO: 
 * - Show a completedPredicate that uses bean method call directly in Java DSL 
 * - Clean up example
 * - test thoroughly
 * - fill XML messages with usefule content
 */

/**
 * Sample RouteBuilder that shows how to use a Camel Aggregator in Java DSL
 * Different techniques are being shown here.
 * 
 * @author TMIELKE, TMIELKE@progress.com
 */

public class QuickRoutesBuilder extends RouteBuilder {
	
  //simple sample message to test against without having to use the Splitter
	public final static String MSG2 = 
	"<artist genre='Rock'>" +
	"  <name>Red Hot Chili Peppers</name>" +
	"  <album>Californication</album>" +
	"  <album>Blood Sugar Sex Magik</album>" +
	"  <album>One Hot Minute</album>" +
	"</artist>";
	
	//complex sample message to test against but being sent through splitter first.
	public final static String SPLITTER_MSG = "<root>" +
	"<artist genre='Rock'>" +
	"  <name>The Rolling Stones</name>" +
	"  <album>Let It Bleed</album>" +
	"  <album>Stripped</album>" +
	"  <album>Forty Licks</album>" +
	"</artist>" +
	"<artist genre='Alternative'>" +
	"  <name>White Stripes</name>" +
	"  <album>Elephant</album>" +
	"  <album>Get Behind Me Satan</album>" +
	"  <album>White Blood Cells</album>" +
	"</artist>" +
	"<artist genre='Jazz'>" +
	"  <name>Jamie Cullum</name>" +
	"  <album>Twenty Something</album>" +
	"  <album>Catching Tales</album>" +
	"  <album>Pointless Nostalgic</album>" +
	"</artist>" +
	"<artist genre='World'>" +
	"  <name>Laura Lopez Castro</name>" +
	"  <album>Mi Libro Abierto</album>" +
	"</artist>" +
	"<artist genre='Rock'>" +
	"  <name>Keane</name>" +
	"  <album>Perfect Symmetry</album>" +
	"  <album>Under the Iron Sea</album>" +
	"  <album>Hopes and Fears</album>" +
	"</artist>" +
	"</root>";
	
	//dummy message that has a completely different format
	public final static String MSG3 = "<root>1</root>";
	
 
	public void configure() throws Exception {
		
		/** --------------- PRODUCE MESSAGES ------------------------------------*/
		
		/********** Fire XML message into a Camel Splitter component **********/
		//This example will break up the complex SPLITTER_MSG into smaller messages
		//with <artist> as the root element. 
		XPathBuilder xPathBuilder = new XPathBuilder("/root/artist");
		//run timer only once by setting period to -1
		from("timer://tutorial?period=1000").
		setBody(constant(SPLITTER_MSG)).
		setHeader("Test", constant("Yes")).
		split(xPathBuilder).
		//to("log:AfterSplitter?level=INFO&showExchangeId=true").
		to("seda:Temp");

		
		/********** Fire dummy message of different format **********/
		from("timer://tutorial?period=2000").
		setBody(constant(MSG3)).
		to("seda:Temp");

		
		
		
		
		/** --------------- AGGREGATE MESSAGES ----------------------------------*/
		/** There are different examples shown below which should all work, but only
		 *  one of these routes should be active at a time.
		 */
		
		/********** Aggregate route based on message header existence **********/
		/*
		from("seda:Temp").			
		aggregate(header("Test"), new MyAggregationStrategy()).
		completedPredicate(header("aggregated").isEqualTo(5)).
		to("log:AggregatedViaHeader?level=INFO&showExchangeId=true");
		*/
		
		/***** Aggregate based on message header and use completedPredicate ******/
		//reference to "aggregatorStrategy" as used in completed predicate must be 
		//defined in Spring xml (camel-context.xml)
		/*
		from("seda:Temp").			
		aggregate(header("Test"), new MyAggregationStrategy()).
		completedPredicate(new BeanExpression("aggregatorStrategy", "isCompleted")).
		to("log:TestAggregatorLogger2?level=INFO&showExchangeId=true");
		*/

		
		/******** Aggregate route based on XPath expression **********/
		/*
		 * Note on the aggregator config below.
		 * When using xpath("/artist"), it returns a NodeList object internally as 
		 * a correlation key when evaluating the correlation expression. 
		 * (See org.apache.camel.processor.aggregate.DefaultAggregationCollection.add())
		 * That NodeList is a different object reference for each incoming msg, so 
		 * the correlation key differs each time and hence no aggregation occurs.
		 * Using xpath("name(/artist)") results in an "Invalid xpath: name(/artist)"
		 * error at runtime as it internally still requires a NodeList object to be
		 * returned.
		 * The trick is to configure the xpath part of your correlation expression 
		 * to return a String or other type instead of a new NodeList instance. 
		 * That String can then serve as the correlation key.
		 * Using xpath("name(artist)", String.class) will do that trick for you! 
		 * This will return the String "artist" back as the correlation key and 
		 * that key will be the same for each msg of the same format, hence 
		 * aggregation will work correctly.
		 */

/*		
		//Aggregate based on <artist> being the root element.
		//finish when 5 *incoming msgs* were processed
 		from("seda:Temp").
 		aggregate(new MyAggregationStrategy()).
 		xpath("name(/artist)", String.class).
 		batchSize(5).
 		to("log:AggregateOnXPath1?level=INFO&showExchangeId=true");

 		//As above but aggregation will finish when 5 messages have been aggregated 
 		//in *each* exchange
		from("seda:Temp").
		aggregate(new MyAggregationStrategy()).
 		xpath("name(/artist)", String.class).
 		completedPredicate(header("aggregated").isEqualTo(5)).
 		to("log:AggregateOnXPath2?level=INFO&showExchangeId=true");
*/

		//Aggregate based on the genre attribute of the <artist> element.
		//Aggregation will finish when 5 messages have been aggregated in each 
 		//exchange
 		from("seda:Temp").
		aggregate(new MyAggregationStrategy()).
		xpath("/artist/@genre", String.class).
		completedPredicate(header("aggregated").isEqualTo(5)).
		to("log:AggregateOnXPath3?level=INFO&showExchangeId=true");

/* 		
		//This example will aggregate all messages starting with 
 		//<artist genre='rock'> into one exchange and all the other messages 
 		//(different genre *or* different root element) into another exchange.		
		from("seda:Temp").
		aggregate(new MyAggregationStrategy()).
		xpath("name(/artist[@genre='Rock'])", String.class).
		batchSize(5).
		to("log:AggregateOnXPath4?level=INFO&showExchangeId=true");
*/
	}
}